from django.apps import AppConfig


class KadaiAppConfig(AppConfig):
    name = 'kadai_app'
