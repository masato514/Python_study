from scipy.io import wavfile
import numpy as np
from scipy.signal import windows

IN_WAVE_FILE = "Nightcore - Cherry Gum (Lyrics).wav"   # 16bit モノラル音声（前提）
OUT_WAVE_FILE = "out.wav"

PITCH = 1.5                    # ピッチの倍率
N_TERM = 30                    # 標本化定理の近似項数
RATE = 1.0 / PITCH             # 再生速度の倍率

fs, data_in = wavfile.read(IN_WAVE_FILE)

def resampling(data_in):
    """ リサンプリング （音を高く/低くするが再生時間も変わる）"""

    # wavの読み込み
    data_in = data_in.astype(np.float64)
    n_samples = len(data_in)

    n_samples_out = int(n_samples / PITCH)
    data_out = np.zeros(n_samples_out)

    for n in range(n_samples_out):
        analog_time = PITCH * n          # アナログ信号の時刻 t を求める
        digital_time = int(analog_time)  # 整数値に変換

        # 標本化定理に基づくアナログ信号復元によるリサンプリング
        sum_index = np.arange(digital_time - N_TERM // 2,
                              digital_time + N_TERM // 2 + 1)
        start_index = np.min(np.where(sum_index >= 0))
        end_index = np.max(np.where(sum_index <= n_samples))
        sinc_vector = np.sinc(analog_time - sum_index[start_index:end_index])
        #data_out[n] = data_in[sum_index[start_index:end_index]].dot(sinc_vector)
        print(data_in[sum_index[start_index:end_index]])
        print(sinc_vector)


if __name__ in '__main__':
    resampling(data_in)