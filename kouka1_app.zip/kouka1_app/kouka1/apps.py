from django.apps import AppConfig


class Kouka1Config(AppConfig):
    name = 'kouka1'
